/home/hexiongjun/SmartAuto/prebuilt/toolchains/arm-fsl-linux-gnueabi/4.6.2/bin/arm-fsl-linux-gnueabi-gcc -O2 -o dhrystone dhry21a.c dhry21b.c timers.c 
