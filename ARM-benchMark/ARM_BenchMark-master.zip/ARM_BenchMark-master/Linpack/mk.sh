/home/hexiongjun/SmartAuto/prebuilt/toolchains/arm-fsl-linux-gnueabi/4.6.2/bin/arm-fsl-linux-gnueabi-gcc -march=armv7-a -mfloat-abi=softfp -mfpu=neon -o linpack linpack.c
