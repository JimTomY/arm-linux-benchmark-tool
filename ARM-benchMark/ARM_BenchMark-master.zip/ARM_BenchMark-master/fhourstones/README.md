The Fhourstones benchmark
=========================

This is the GitHub home of the Fhourstones benchmark by John Tromp.

Homepage: http://homepages.cwi.nl/~tromp/c4/fhour.html

