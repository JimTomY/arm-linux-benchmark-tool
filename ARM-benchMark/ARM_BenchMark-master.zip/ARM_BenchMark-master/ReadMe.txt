Integer--fhourstons
dhrystone-src:integer
