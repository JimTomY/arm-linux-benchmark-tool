ARM_BenchMark
=============

A copy from of ARM Benchmark tools souce code: lmbench dhrystone fhourstones Linpack whetstone.
I have written [a summary article](http://tonyho.github.io/ARM%20Linux%20BenchMark.html) about the ARM benchmark.
